<?php include 'includes/config.php';?>
<?php include 'includes/contact_header.php';?>

<link href="https://fonts.googleapis.com/css?family=Knewave" rel="stylesheet">

<section>
 <center style="font-family: 'Knewave', cursive;"> <font size="6"> Contact </font></center> 
    <?php
        include 'includes/multiple.php';
    ?>
</section>


<?php include 'includes/footer.php'?>
