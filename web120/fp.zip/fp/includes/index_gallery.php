<!-- MAIN (Center website) -->
<html>
<body>
<div class="main">


<center><h2 style="font-family: 'Reenie Beanie', cursive;">PORTFOLIO</h2></center>

<!-- Portfolio Gallery Grid -->
<div class="row">
  <div class="column">
    <div class="content">
      <img src="http://www.christiangunning92.dreamhosters.com/web120/fp/images/DIFFERENT_LIGHT_rolfes1%20copy.png" alt="album_art" style="width:100%">
      <h3>Album Art</h3>
      <p>Lorem ipsum dolor sit amet, tempor prodesset eos no. Temporibus necessitatibus sea ei, at tantas oporteat nam. Lorem ipsum dolor sit amet, tempor prodesset eos no.</p>
    </div>
  </div>
  <div class="column">
    <div class="content">
    <img src="http://www.christiangunning92.dreamhosters.com/web120/fp/images/IMG_0436.jpg" alt="album_art_2" style="width:100%">
      <h3>Album Art</h3>
      <p>Lorem ipsum dolor sit amet, tempor prodesset eos no. Temporibus necessitatibus sea ei, at tantas oporteat nam. Lorem ipsum dolor sit amet, tempor prodesset eos no.</p>
    </div>
  </div>
  <div class="column">
    <div class="content">
    <img src="http://www.christiangunning92.dreamhosters.com/web120/fp/images/shelf_nunny%20copy.png" alt="Nature" style="width:100%">
      <h3>My Work</h3>
      <p>Lorem ipsum dolor sit amet, tempor prodesset eos no. Temporibus necessitatibus sea ei, at tantas oporteat nam. Lorem ipsum dolor sit amet, tempor prodesset eos no.</p>
    </div>
  </div>
  <div class="column">
    <div class="content">
    <img src="http://www.christiangunning92.dreamhosters.com/web120/fp/images/IMG_0513%20(1).JPG" alt="Mountains" style="width:100%">
      <h3>My Work</h3>
      <p>Lorem ipsum dolor sit amet, tempor prodesset eos no. Temporibus necessitatibus sea ei, at tantas oporteat nam. Lorem ipsum dolor sit amet, tempor prodesset eos no.</p>
    </div>
  </div>
<!-- END GRID -->
</div>

<div class="content">
  <img src="http://www.christiangunning92.dreamhosters.com/web120/fp/images/IMG_0635.jpeg" alt="Artist" style="width:100%">
  <h3>Some Other Work</h3>
  <p>Lorem ipsum dolor sit amet, tempor prodesset eos no. Temporibus necessitatibus sea ei, at tantas oporteat nam. Lorem ipsum dolor sit amet, tempor prodesset eos no.</p>
  <p>Lorem ipsum dolor sit amet, tempor prodesset eos no. Temporibus necessitatibus sea ei, at tantas oporteat nam. Lorem ipsum dolor sit amet, tempor prodesset eos no.</p>
</div>

<!-- END MAIN -->
</div>
</body>
</html>
