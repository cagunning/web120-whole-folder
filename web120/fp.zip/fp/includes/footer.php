<!-- START FOOTER HERE -->
    <!-- START Footer -->
    <html>    
    <footer>
        <p><small>&copy; 2018 - <?=date("Y") ?> by <a href="http://www.christiangunning92.dreamhosters.com/web120/contactme.php" target="_blank">Contact Hella fitzGerald</a>, All Rights Reserved ~ <a href="http://validator.w3.org/check/referer" target="_blank">Valid HTML</a> ~ <a href="http://jigsaw.w3.org/css-validator/check?uri=referer" target="_blank">Valid CSS</a></small></p>
    </footer>
</html>
    <!-- End Footer -->