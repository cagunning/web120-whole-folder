<html>
<?php include 'includes/config.php';?>
<?php include 'includes/header.php';?>

<link rel="stylesheet" href="css/index.css" />

<link href="https://fonts.googleapis.com/css?family=Knewave" rel="stylesheet">
<link href="https://fonts.googleapis.com/css?family=Reenie+Beanie" rel="stylesheet">
<head>

</head>
<body>

<section>
 <center style="font-family: 'Knewave', cursive;"> <font size="6"> Hella FitzGerald </font></center> 
</section>

<?php include 'includes/index_gallery.php';?>

</body>

<?php include 'includes/footer.php'?>

 

